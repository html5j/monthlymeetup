## Google+ JavaScript Quickstart

The instructions for getting started are available at:
https://developers.google.com/+/quickstart/javascript
